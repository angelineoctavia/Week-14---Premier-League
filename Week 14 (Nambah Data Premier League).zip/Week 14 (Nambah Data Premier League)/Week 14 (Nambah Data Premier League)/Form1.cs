﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;


namespace Week_14__Nambah_Data_Premier_League_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtShowHome;
        DataTable dtShowAway;
        DataTable dtID;
        DataTable dtTampilan;
        DataTable dtPlayer;
        DataTable dtType;
        string query;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Ilikecandiess_270705;database=premier_league");
            dtShowHome = new DataTable();

            /*dtShowHome = new DataTable();
            query = "select team_name, team_id from team";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtShowHome);
            cBox_TeamHome.DataSource = dtShowHome;
            cBox_TeamHome.ValueMember = "team_id";
            cBox_TeamHome.DisplayMember = "team_name";
            cBox_TeamHome.SelectedIndex = -1;

            dtShowAway = new DataTable();
            query = "select team_name, team_id from team";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtShowAway);
            cBox_TeamAway.DataSource = dtShowAway;
            cBox_TeamAway.ValueMember = "team_id";
            cBox_TeamAway.DisplayMember = "team_name";
            cBox_TeamAway.SelectedIndex = -1;*/

            dtShowHome= new DataTable();
            query = "select distinct t.team_name \r\nfrom team t\r\njoin `match` m\r\non t.team_id = m.team_home";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtShowHome);
            for (int i = 0; i < dtShowHome.Rows.Count; i++)
            {
                cBox_TeamHome.Items.Add(dtShowHome.Rows[i][0].ToString());
            }

            dtShowAway = new DataTable();
            query = "select distinct t.team_name \r\nfrom team t\r\njoin `match` m\r\non t.team_id = m.team_home";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtShowAway);
            for (int i = 0; i < dtShowAway.Rows.Count; i++)
            {
                cBox_TeamAway.Items.Add(dtShowAway.Rows[i][0].ToString());
            }


            dtTampilan = new DataTable();
            dtTampilan.Columns.Add("Minute");
            dtTampilan.Columns.Add("Team");
            dtTampilan.Columns.Add("Player");
            dtTampilan.Columns.Add("Type");
            dgv_Show.DataSource = dtTampilan;

            dtType = new DataTable();
            query = "select distinct type from dmatch";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtType);
            for (int i = 0; i < dtType.Rows.Count; i++)
            {
                cBox_Type.Items.Add(dtType.Rows[i][0].ToString());
            }
        }

        private void dtPicker_MatchDate_ValueChanged(object sender, EventArgs e)
        {
            dtID = new DataTable();
            string selectedDateTime = dtPicker_MatchDate.Value.Year.ToString();
            string matchID = selectedDateTime.ToString();
            string IDLama = "";

            query = "select match_id from dmatch order by match_id desc limit 1";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtID);
            IDLama = dtID.Rows[0][0].ToString();

            if (IDLama.Substring(0,4) == dtPicker_MatchDate.Value.Year.ToString())
            {
                int nomorSebelumnya = Convert.ToInt32(IDLama.Substring(4, 3));
                nomorSebelumnya += 1;
                tBox_MatchID.Text = dtPicker_MatchDate.Value.Year + string.Format("{0:d3}", nomorSebelumnya);
            }
            else
            {
                tBox_MatchID.Text = dtPicker_MatchDate.Value.Year + string.Format("{0:d3}",1);
            }

            DateTime selectedDate = dtPicker_MatchDate.Value;
            DateTime minDate = new DateTime(2016, 2, 14);

            if (selectedDate < minDate)
            {
                MessageBox.Show("Error");
            }
        }

        private void cBox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_TeamHome.Text == cBox_TeamAway.Text)
            {
                MessageBox.Show("Error, nama team sama");
            }

            cBox_Team.Items.Clear();
            cBox_Team.Items.Add(cBox_TeamHome.Text);
            cBox_Team.Items.Add(cBox_TeamAway.Text);
        }

        private void cBox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_TeamHome.Text == cBox_TeamAway.Text)
            {
                MessageBox.Show("Error, nama team sama");
            }

            cBox_Team.Items.Clear();
            cBox_Team.Items.Add(cBox_TeamHome.Text);
            cBox_Team.Items.Add(cBox_TeamAway.Text);
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tBox_Minute.Text) || cBox_Team.SelectedIndex == -1 || cBox_Player.SelectedIndex == -1 || cBox_Type.SelectedIndex == -1)
            {
                MessageBox.Show("Error, ada yang kosong");
            }
            else
            {
                string minute = tBox_Minute.Text;
                string team = cBox_Team.Text;
                string player = cBox_Player.Text;
                string type = cBox_Type.Text;
                dtTampilan.Rows.Add(minute, team, player, type);
            }

            dgv_Show.ClearSelection();
        }

        private void cBox_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer = new DataTable();
            query = $"select p.player_name from player p join team t on p.team_id = t.team_id where t.team_name = '{cBox_Team.Text}';";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);
            for (int i = 0; i < dtPlayer.Rows.Count; i++)
            {
                cBox_Player.Items.Add(dtPlayer.Rows[i][0].ToString());
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_Show.SelectedRows.Count > 0)
            {
                dgv_Show.Rows.RemoveAt(dgv_Show.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Pilih baris yang ingin dihapus.");
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            sqlConnect.Open();
            sqlCommand = sqlConnect.CreateCommand();
            query = "insert into dmatch values (@match_id, @minute, @team_id, @player_id, @type, @delete)";
            sqlCommand.CommandText = query;
            sqlCommand.Parameters.AddWithValue("@match_id", tBox_MatchID.Text);
            sqlCommand.Parameters.AddWithValue("@minute", tBox_Minute.Text);
            sqlCommand.Parameters.AddWithValue("@team_id", cBox_TeamHome.ValueMember);
           //sqlCommand.Parameters.AddWithValue("@player_id", tBox_NIM.Text);
            sqlCommand.Parameters.AddWithValue("@type", cBox_Type.Text);
           //sqlCommand.Parameters.AddWithValue("@delete", tBox_NIM.Text);
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
        }
    }
}

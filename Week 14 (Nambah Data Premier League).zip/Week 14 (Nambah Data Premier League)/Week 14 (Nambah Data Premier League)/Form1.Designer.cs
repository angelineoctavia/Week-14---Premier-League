﻿namespace Week_14__Nambah_Data_Premier_League_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MatchID = new System.Windows.Forms.Label();
            this.lbl_TeamHome = new System.Windows.Forms.Label();
            this.tBox_MatchID = new System.Windows.Forms.TextBox();
            this.cBox_TeamHome = new System.Windows.Forms.ComboBox();
            this.lbl_MatchDate = new System.Windows.Forms.Label();
            this.lbl_TeamAway = new System.Windows.Forms.Label();
            this.dtPicker_MatchDate = new System.Windows.Forms.DateTimePicker();
            this.cBox_TeamAway = new System.Windows.Forms.ComboBox();
            this.dgv_Show = new System.Windows.Forms.DataGridView();
            this.lbl_Minute = new System.Windows.Forms.Label();
            this.lbl_Team = new System.Windows.Forms.Label();
            this.lbl_Player = new System.Windows.Forms.Label();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.tBox_Minute = new System.Windows.Forms.TextBox();
            this.cBox_Team = new System.Windows.Forms.ComboBox();
            this.cBox_Player = new System.Windows.Forms.ComboBox();
            this.cBox_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Show)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_MatchID
            // 
            this.lbl_MatchID.AutoSize = true;
            this.lbl_MatchID.Location = new System.Drawing.Point(61, 72);
            this.lbl_MatchID.Name = "lbl_MatchID";
            this.lbl_MatchID.Size = new System.Drawing.Size(97, 25);
            this.lbl_MatchID.TabIndex = 0;
            this.lbl_MatchID.Text = "Match ID";
            // 
            // lbl_TeamHome
            // 
            this.lbl_TeamHome.AutoSize = true;
            this.lbl_TeamHome.Location = new System.Drawing.Point(61, 132);
            this.lbl_TeamHome.Name = "lbl_TeamHome";
            this.lbl_TeamHome.Size = new System.Drawing.Size(128, 25);
            this.lbl_TeamHome.TabIndex = 1;
            this.lbl_TeamHome.Text = "Team Home";
            // 
            // tBox_MatchID
            // 
            this.tBox_MatchID.Enabled = false;
            this.tBox_MatchID.Location = new System.Drawing.Point(225, 66);
            this.tBox_MatchID.Name = "tBox_MatchID";
            this.tBox_MatchID.Size = new System.Drawing.Size(236, 31);
            this.tBox_MatchID.TabIndex = 2;
            // 
            // cBox_TeamHome
            // 
            this.cBox_TeamHome.FormattingEnabled = true;
            this.cBox_TeamHome.Location = new System.Drawing.Point(225, 124);
            this.cBox_TeamHome.Name = "cBox_TeamHome";
            this.cBox_TeamHome.Size = new System.Drawing.Size(236, 33);
            this.cBox_TeamHome.TabIndex = 3;
            this.cBox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamHome_SelectedIndexChanged);
            // 
            // lbl_MatchDate
            // 
            this.lbl_MatchDate.AutoSize = true;
            this.lbl_MatchDate.Location = new System.Drawing.Point(594, 72);
            this.lbl_MatchDate.Name = "lbl_MatchDate";
            this.lbl_MatchDate.Size = new System.Drawing.Size(122, 25);
            this.lbl_MatchDate.TabIndex = 4;
            this.lbl_MatchDate.Text = "Match Date";
            // 
            // lbl_TeamAway
            // 
            this.lbl_TeamAway.AutoSize = true;
            this.lbl_TeamAway.Location = new System.Drawing.Point(594, 132);
            this.lbl_TeamAway.Name = "lbl_TeamAway";
            this.lbl_TeamAway.Size = new System.Drawing.Size(124, 25);
            this.lbl_TeamAway.TabIndex = 5;
            this.lbl_TeamAway.Text = "Team Away";
            // 
            // dtPicker_MatchDate
            // 
            this.dtPicker_MatchDate.Location = new System.Drawing.Point(751, 64);
            this.dtPicker_MatchDate.Name = "dtPicker_MatchDate";
            this.dtPicker_MatchDate.Size = new System.Drawing.Size(359, 31);
            this.dtPicker_MatchDate.TabIndex = 6;
            this.dtPicker_MatchDate.ValueChanged += new System.EventHandler(this.dtPicker_MatchDate_ValueChanged);
            // 
            // cBox_TeamAway
            // 
            this.cBox_TeamAway.FormattingEnabled = true;
            this.cBox_TeamAway.Location = new System.Drawing.Point(751, 124);
            this.cBox_TeamAway.Name = "cBox_TeamAway";
            this.cBox_TeamAway.Size = new System.Drawing.Size(236, 33);
            this.cBox_TeamAway.TabIndex = 7;
            this.cBox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamAway_SelectedIndexChanged);
            // 
            // dgv_Show
            // 
            this.dgv_Show.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Show.Location = new System.Drawing.Point(66, 208);
            this.dgv_Show.Name = "dgv_Show";
            this.dgv_Show.RowHeadersWidth = 82;
            this.dgv_Show.RowTemplate.Height = 33;
            this.dgv_Show.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Show.Size = new System.Drawing.Size(685, 319);
            this.dgv_Show.TabIndex = 8;
            // 
            // lbl_Minute
            // 
            this.lbl_Minute.AutoSize = true;
            this.lbl_Minute.Location = new System.Drawing.Point(780, 257);
            this.lbl_Minute.Name = "lbl_Minute";
            this.lbl_Minute.Size = new System.Drawing.Size(77, 25);
            this.lbl_Minute.TabIndex = 9;
            this.lbl_Minute.Text = "Minute";
            // 
            // lbl_Team
            // 
            this.lbl_Team.AutoSize = true;
            this.lbl_Team.Location = new System.Drawing.Point(780, 301);
            this.lbl_Team.Name = "lbl_Team";
            this.lbl_Team.Size = new System.Drawing.Size(66, 25);
            this.lbl_Team.TabIndex = 10;
            this.lbl_Team.Text = "Team";
            // 
            // lbl_Player
            // 
            this.lbl_Player.AutoSize = true;
            this.lbl_Player.Location = new System.Drawing.Point(780, 345);
            this.lbl_Player.Name = "lbl_Player";
            this.lbl_Player.Size = new System.Drawing.Size(73, 25);
            this.lbl_Player.TabIndex = 11;
            this.lbl_Player.Text = "Player";
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Location = new System.Drawing.Point(780, 386);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(60, 25);
            this.lbl_Type.TabIndex = 12;
            this.lbl_Type.Text = "Type";
            // 
            // tBox_Minute
            // 
            this.tBox_Minute.Location = new System.Drawing.Point(874, 254);
            this.tBox_Minute.Name = "tBox_Minute";
            this.tBox_Minute.Size = new System.Drawing.Size(236, 31);
            this.tBox_Minute.TabIndex = 13;
            // 
            // cBox_Team
            // 
            this.cBox_Team.FormattingEnabled = true;
            this.cBox_Team.Location = new System.Drawing.Point(874, 298);
            this.cBox_Team.Name = "cBox_Team";
            this.cBox_Team.Size = new System.Drawing.Size(236, 33);
            this.cBox_Team.TabIndex = 14;
            this.cBox_Team.SelectedIndexChanged += new System.EventHandler(this.cBox_Team_SelectedIndexChanged);
            // 
            // cBox_Player
            // 
            this.cBox_Player.FormattingEnabled = true;
            this.cBox_Player.Location = new System.Drawing.Point(874, 342);
            this.cBox_Player.Name = "cBox_Player";
            this.cBox_Player.Size = new System.Drawing.Size(236, 33);
            this.cBox_Player.TabIndex = 15;
            // 
            // cBox_Type
            // 
            this.cBox_Type.FormattingEnabled = true;
            this.cBox_Type.Location = new System.Drawing.Point(874, 383);
            this.cBox_Type.Name = "cBox_Type";
            this.cBox_Type.Size = new System.Drawing.Size(236, 33);
            this.cBox_Type.TabIndex = 16;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(814, 442);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(138, 46);
            this.btn_Add.TabIndex = 17;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(972, 442);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(138, 46);
            this.btn_Delete.TabIndex = 18;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(436, 566);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(315, 46);
            this.btn_Insert.TabIndex = 19;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 672);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cBox_Type);
            this.Controls.Add(this.cBox_Player);
            this.Controls.Add(this.cBox_Team);
            this.Controls.Add(this.tBox_Minute);
            this.Controls.Add(this.lbl_Type);
            this.Controls.Add(this.lbl_Player);
            this.Controls.Add(this.lbl_Team);
            this.Controls.Add(this.lbl_Minute);
            this.Controls.Add(this.dgv_Show);
            this.Controls.Add(this.cBox_TeamAway);
            this.Controls.Add(this.dtPicker_MatchDate);
            this.Controls.Add(this.lbl_TeamAway);
            this.Controls.Add(this.lbl_MatchDate);
            this.Controls.Add(this.cBox_TeamHome);
            this.Controls.Add(this.tBox_MatchID);
            this.Controls.Add(this.lbl_TeamHome);
            this.Controls.Add(this.lbl_MatchID);
            this.Name = "Form1";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_MatchID;
        private System.Windows.Forms.Label lbl_TeamHome;
        private System.Windows.Forms.TextBox tBox_MatchID;
        private System.Windows.Forms.ComboBox cBox_TeamHome;
        private System.Windows.Forms.Label lbl_MatchDate;
        private System.Windows.Forms.Label lbl_TeamAway;
        private System.Windows.Forms.DateTimePicker dtPicker_MatchDate;
        private System.Windows.Forms.ComboBox cBox_TeamAway;
        private System.Windows.Forms.DataGridView dgv_Show;
        private System.Windows.Forms.Label lbl_Minute;
        private System.Windows.Forms.Label lbl_Team;
        private System.Windows.Forms.Label lbl_Player;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.TextBox tBox_Minute;
        private System.Windows.Forms.ComboBox cBox_Team;
        private System.Windows.Forms.ComboBox cBox_Player;
        private System.Windows.Forms.ComboBox cBox_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Insert;
    }
}

